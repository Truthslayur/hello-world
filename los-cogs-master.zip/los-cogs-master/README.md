# League of Studs Cogs
A collection of cogs for the LOS discord server's resident bots.

## Getting started
1. create your own discord server for testing at discordapp.com.
2. follow the instructions at https://twentysix26.github.io/Red-Docs/ to install a local version of Red Discord bot
3. clone this repo
4. add this repo to your local red install with: `!cog repo add los-cogs <path-to-local-repo>`
5. install each cog with: `!cog install los-cogs <cog-name>`
